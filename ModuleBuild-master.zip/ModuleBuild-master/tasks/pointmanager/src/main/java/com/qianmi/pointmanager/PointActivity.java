package com.qianmi.pointmanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.qianmi.baselibrary.BaseActivity;


public class PointActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point);
    }
}
