package com.qianmi.baselibrary;

/**
 * Created by su on 2016/6/27.
 */
public class AppConfig {

    public static final String PointManagerModuleActivity = "com.qianmi.pointmanager.PointActivity";
    public static final String OrderManagerModuleActivity = "com.qianmi.small.orderlibrary.OrderActivity";

    public static final String ORDER_INTENT_VALUE = "orderIntentValue";

}
