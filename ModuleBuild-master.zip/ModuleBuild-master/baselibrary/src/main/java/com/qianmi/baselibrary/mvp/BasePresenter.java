package com.qianmi.baselibrary.mvp;

/**
 * Created by su on 2016/6/25.
 */
public interface BasePresenter  {
    void start();
}
