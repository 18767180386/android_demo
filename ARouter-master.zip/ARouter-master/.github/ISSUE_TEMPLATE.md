## Look at here

- → Did you read the doc carefully
- → Did you add annotation above target activity
- → Did you add annotation processor dependence
- → **Receive only bugs and suggestions**