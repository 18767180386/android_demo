# Android组件化案例

[Android组件化开发实战地址](http://www.jikexueyuan.com/zhiye/course/84.html?type=18)


组件化优点：
-  便于团队进行并行开发，组件可采用架构无耦合。
 
-  任意任意任意切换Lib模式或者Application模式

-   加快编译时间，提升开发效率

-  多个组件可以重复使用

-  便于测试单独测试某一模块


详细介绍请参见[Anroid组件化案例](http://blog.csdn.net/asddavid/article/details/54599688)
